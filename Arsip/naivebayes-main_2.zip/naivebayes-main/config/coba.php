<?php

echo 'dari config coba';

?>