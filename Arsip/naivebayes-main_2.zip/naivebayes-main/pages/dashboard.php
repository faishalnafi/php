<!--begin::App Content Header-->
<div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0">Welcome <strong><?php echo htmlspecialchars($_SESSION['name']); ?></strong></h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    Dashboard
                                </li>
                            </ol>
                        </div>
                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Container-->
            </div>
            <!--end::App Content Header-->
            <!--begin::App Content-->
            <!-- <div class="app-content">
                <--begin::Container--
                <div class="container-fluid">
                    <--begin::Row--
                    <form method="POST" action="./excelupload.php" enctype="multipart/form-data">
            <div class="form-group">
                    <label>Upload Excel File</label>
                    <input type="file" name="file" class="form-control">
            </div>
            <div class="form-group">
                    <button type="submit" name="submit" class="btn btn-success">Upload</button>
            </div> -->
    </form>
        <!-- <div class="row">
        <div class="card">
            <div class="card-header">
                <h1>Data Table</h1>
            </div>
            <div class="card-body">

<?php

$data = mysqli_query($con,"SELECT * FROM naive_bayes_prediction");
$no = 1;
?>
<table id="example2" class="table table-bordered table-striped table-hover">
        <thead>
                <tr>
                        <th>No</th>
                        <th>Jenis Kelamin</th>
                        <th>Kelas</th>
                </tr>
        </thead>
        <tbody>
                <?php foreach($data as $row):?>
                <tr>
                        <td><?php echo $no++?></td>
                        <td><?php $jk = isset($row['jenis_kelamin']) ?  $row['jenis_kelamin'] : ''; echo $jk?></td>
                        <td><?php $jk = isset($row['kelas']) ?  $row['kelas'] : ''; echo $jk?></td>
                </tr>
                <?php endforeach;?>
        </tbody>
</table>
            </div>
        </div>
        
        </div>
                    <-- /.row (main row) --
                </div>
                <--end::Container--
            </div> -->
