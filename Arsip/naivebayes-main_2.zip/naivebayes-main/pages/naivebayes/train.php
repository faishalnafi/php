<?php

use PhpOffice\PhpSpreadsheet\Reader\Xlsx;

if(isset($_POST['submit'])){
    $mimes = array(
        'text/xls','text/xlsx','application/excel','application/vnd.msexcel','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    );
    if(!empty($_FILES['file']['name']) && in_array($_FILES["file"]["type"],$mimes)){
        if(is_uploaded_file($_FILES['file']['tmp_name'])){
            $reader = new Xlsx();
            $reader->setLoadSheetsOnly('NAIVE BAYES');
            $spreadsheet = $reader->load($_FILES['file']['tmp_name']);
            $sheet = $spreadsheet->getActiveSheet();
            $sheet_arr = $sheet->toArray();
            unset($sheet_arr[0]);

            foreach ($sheet_arr as $Row)
            {
            
            $jk = isset($Row[0]) ? $Row[0] : '';
            $variasiproduk = isset($Row[1]) ? $Row[1] : '';
            $hargaproduk = isset($Row[2]) ? $Row[2] : '';
            $interaksipenjual = isset($Row[3]) ? $Row[3] : '';
            $pelayananpelanggan = isset($Row[4]) ? $Row[4] : '';
            $kualitasproduk = isset($Row[5]) ? $Row[5] : '';
            $prosespembelian = isset($Row[6]) ? $Row[6] : '';
            $kecepatanrespon = isset($Row[7]) ? $Row[7] : '';
            $penanganankeluhan = isset($Row[8]) ? $Row[8] : '';
            $kelas = isset($Row[9]) ? $Row[9] : '';
            
            $query = "insert into naive_bayes_train values('".$jk."','".$variasiproduk."','".$hargaproduk."','".$interaksipenjual."','".$pelayananpelanggan."','".$kualitasproduk."','".$prosespembelian."','".$kecepatanrespon."','".$penanganankeluhan."','".$kelas."')";
            mysqli_query($con,"INSERT INTO naive_bayes_train VALUES(null,'$jk','$variasiproduk','$hargaproduk','$interaksipenjual','$pelayananpelanggan','$kualitasproduk','$prosespembelian','$kecepatanrespon','$penanganankeluhan','$kelas')");
            }
            echo "<script>window.location.href='index.php?p=naivebayes&act=train'</script>";
        }
    }
}

?>
<div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0">Data Train</h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    Data Train
                                </li>
                            </ol>
                        </div>
                    </div>
                    <!--end::Row-->
                    <form method="POST" action="" enctype="multipart/form-data">
                            <div class="form-group">
                                    <label>Upload Excel File</label>
                                    <input type="file" name="file" class="form-control">
                            </div>
                            <div class="form-group">
                                    <button type="submit" name="submit" class="btn btn-success">Upload</button>
                            </div>
                    </form>
                </div>
                <!--end::Container-->
            </div>
<?php
$data = mysqli_query($con,"SELECT * FROM naive_bayes_train");
$numdata = mysqli_num_rows($data);
$dataArray = [];
$datatrain = ceil($numdata * 0.925);
while($row = mysqli_fetch_assoc($data)){
    $dataArray[] = $row;
}
$no = 1;
?>
<div class="app-content">
    <div class="container-fluid">
        <table id="example2" class="table table-bordered table-striped table-hover">
            <thead>
                    <tr>
                            <th>No</th>
                            <th>Jenis Kelamin</th>
                            <th>Variasi Produk</th>
                            <th>Harga Produk</th>
                            <th>Interaksi Penjual</th>
                            <th>Pelayanan Pelanggan</th>
                            <th>Kualitas Produk</th>
                            <th>Proses Pembelian</th>
                            <th>Kecepatan Respon</th>
                            <th>Penanganan Keluhan</th>
                            <th>Kelas</th>
                    </tr>
            </thead>
            <tbody>
                    <?php for ($i=0; $i < $datatrain; $i++) { ?>
                        <tr>
                            <td><?php echo $no++?></td>
                            <td><?php echo $dataArray[$i]['jenis_kelamin'] ?? '';?></td>
                            <td><?php echo $dataArray[$i]['variasi_produk'] ?? '';?></td>
                            <td><?php echo $dataArray[$i]['harga_produk'] ?? '';?></td>
                            <td><?php echo $dataArray[$i]['interaksi_penjual'] ?? '';?></td>
                            <td><?php echo $dataArray[$i]['pelayanan_pelanggan'] ?? '';?></td>
                            <td><?php echo $dataArray[$i]['kualitas_produk'] ?? '';?></td>
                            <td><?php echo $dataArray[$i]['proses_pembelian'] ?? '';?></td>
                            <td><?php echo $dataArray[$i]['kecepatan_respon'] ?? '';?></td>
                            <td><?php echo $dataArray[$i]['penanganan_keluhan'] ?? '';?></td>
                            <td><?php echo $dataArray[$i]['kelas'] ?? '';?></td>
                        </tr>
                    <?php } ?>
            </tbody>
        </table>
    </div>
</div>
