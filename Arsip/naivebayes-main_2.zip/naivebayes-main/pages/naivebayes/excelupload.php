<?php
require_once '../vendor/autoload.php';
require('../config/connection.php');
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;

if(isset($_POST['submit'])){
  //$mimes = ['application/vnd.ms-excel','text/xls','text/xlsx','application/vnd.oasis.opendocument.spreadsheet'];
  $mimes = array(
    'text/xls','text/xlsx','application/excel','application/vnd.msexcel','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  );
  //echo $_FILES['file']['tmp_name'];
  //$uploadFilePath = $_FILES['file']['tmp_name'];

    // Verify the file exists
    // if (!file_exists($uploadFilePath)) {
    //     die("File not found at path: $uploadFilePath");
    // }
  // echo $_FILES['file']['name'];
  // echo $_FILES['file']['tmp_name'];
  if(!empty($_FILES['file']['name']) && in_array($_FILES["file"]["type"],$mimes)){
    // $uploadFilePath = 'uploads/'.basename($_FILES['file']['name']);
    // move_uploaded_file($_FILES['file']['tmp_name'], $uploadFilePath);
    if(is_uploaded_file($_FILES['file']['tmp_name'])){
      $reader = new Xlsx();
      $reader->setLoadSheetsOnly('NAIVE BAYES');
      $spreadsheet = $reader->load($_FILES['file']['tmp_name']);
      $sheet = $spreadsheet->getActiveSheet();
      $sheet_arr = $sheet->toArray();
      unset($sheet_arr[0]);
      
  
      $html="<table border='1'>";
      $html.="<tr><th>Title</th><th>Description</th></tr>";
      /* For Loop for all sheets */
  
      
        foreach ($sheet_arr as $Row)
        {
          $html.="<tr>";
          $jk = isset($Row[0]) ? $Row[0] : '';
          $variasiproduk = isset($Row[1]) ? $Row[1] : '';
          $hargaproduk = isset($Row[2]) ? $Row[2] : '';
          $interaksipenjual = isset($Row[3]) ? $Row[3] : '';
          $pelayananpelanggan = isset($Row[4]) ? $Row[4] : '';
          $kualitasproduk = isset($Row[5]) ? $Row[5] : '';
          $prosespembelian = isset($Row[6]) ? $Row[6] : '';
          $kecepatanrespon = isset($Row[7]) ? $Row[7] : '';
          $penanganankeluhan = isset($Row[8]) ? $Row[8] : '';
          $kelas = isset($Row[9]) ? $Row[9] : '';
          $html.="<td>".$jk."</td>";
          $html.="<td>".$variasiproduk."</td>";
          $html.="</tr>";
          $query = "insert into naive_bayes values('".$jk."','".$variasiproduk."','".$hargaproduk."','".$interaksipenjual."','".$pelayananpelanggan."','".$kualitasproduk."','".$prosespembelian."','".$kecepatanrespon."','".$penanganankeluhan."','".$kelas."')";
          mysqli_query($con,"INSERT INTO naive_bayes VALUES(null,'$jk','$variasiproduk','$hargaproduk','$interaksipenjual','$pelayananpelanggan','$kualitasproduk','$prosespembelian','$kecepatanrespon','$penanganankeluhan','$kelas')");
         }
      $html.="</table>";
      echo $html;
      echo "<br />Data Inserted in dababase";
      echo "<script>window.location.href='index.php'</script>";

    }
  }else { 
    die("<br/>Sorry, File type is not allowed. Only Excel file."); 
  }
}
?>
