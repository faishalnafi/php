<?php
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;

if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Fungsi untuk menghitung probabilitas Naive Bayes
function naiveBayesPredict($data, $trainingData) {
    $classProbabilities = [];
    $featureProbabilities = [];

    foreach ($trainingData as $row) {
        $class = $row['kelas'];
        $classProbabilities[$class] = ($classProbabilities[$class] ?? 0) + 1;

        foreach ($data as $feature => $value) {
            if (!isset($featureProbabilities[$class][$feature])) {
                $featureProbabilities[$class][$feature] = [];
            }
            $featureProbabilities[$class][$feature][$value] = ($featureProbabilities[$class][$feature][$value] ?? 0) + 1;
        }
    }

    $totalTrainingData = count($trainingData);
    foreach ($classProbabilities as $class => $count) {
        $classProbabilities[$class] = $count / $totalTrainingData;
    }

    foreach ($featureProbabilities as $class => $features) {
        foreach ($features as $feature => $values) {
            $totalFeatureCount = array_sum($values);
            foreach ($values as $value => $count) {
                $featureProbabilities[$class][$feature][$value] = $count / $totalFeatureCount;
            }
        }
    }

    $predictions = [];
    foreach ($classProbabilities as $class => $classProbability) {
        $probability = $classProbability;
        foreach ($data as $feature => $value) {
            $probability *= $featureProbabilities[$class][$feature][$value] ?? 1e-6;
        }
        $predictions[$class] = $probability;
    }

    arsort($predictions);
    return key($predictions);
}

// Fungsi untuk menghitung akurasi dan confusion matrix
function calculateMetrics($testData, $predictions) {
    $confusionMatrix = [];
    $correctPredictions = 0;
    $totalData = count($testData);

    foreach ($testData as $index => $row) {
        $actualClass = $row['kelas'];
        $predictedClass = $predictions[$index]['predicted_class'] ?? null;

        if (!isset($confusionMatrix[$actualClass])) {
            $confusionMatrix[$actualClass] = [];
        }

        if (!isset($confusionMatrix[$actualClass][$predictedClass])) {
            $confusionMatrix[$actualClass][$predictedClass] = 0;
        }

        $confusionMatrix[$actualClass][$predictedClass]++;

        if ($actualClass === $predictedClass) {
            $correctPredictions++;
        }
    }

    $accuracy = $correctPredictions / $totalData;

    return [
        'accuracy' => $accuracy,
        'confusionMatrix' => $confusionMatrix,
    ];
}

// Upload file Excel
if (isset($_POST['submit']) && isset($_FILES['file'])) {
    $file = $_FILES['file']['tmp_name'];

    if (empty($file)) {
        die('No file uploaded.');
    }

    $reader = new Xlsx();
    $reader->setLoadSheetsOnly('NAIVE BAYES');
    $spreadsheet = $reader->load($file);
    $sheet = $spreadsheet->getActiveSheet();
    $rows = $sheet->toArray();

    $header = array_shift($rows); // Ambil header
    $predictions = [];

    // Ambil data training dari database
    $trainingData = [];
    $result = mysqli_query($con, "SELECT * FROM naive_bayes_train");
    while ($row = mysqli_fetch_assoc($result)) {
        $trainingData[] = $row;
    }

    // Ambil data testing dari database
    $testData = [];
    $result = mysqli_query($con, "SELECT * FROM naive_bayes_test");
    while ($row = mysqli_fetch_assoc($result)) {
        $testData[] = $row;
    }

    foreach ($rows as $row) {
        $data = array_combine($header, $row);
        $predictedClass = naiveBayesPredict($data, $trainingData);
        $predictions[] = array_merge($data, ['predicted_class' => $predictedClass]);
    }

    // Simpan hasil prediksi ke tabel testing
    foreach ($predictions as $prediction) {
        $filteredPrediction = array_filter($prediction, function ($value) {
            return $value !== null; // Hanya ambil nilai yang tidak null
        });
        $columns = implode(',', array_keys($filteredPrediction));
        $values = implode(',', array_map(function ($value) use ($con) {
            return "'" . mysqli_real_escape_string($con, (string) $value) . "'";
        }, array_values($filteredPrediction)));

        $columns = strtolower(str_replace(' ', '_', $columns));
        $query = "INSERT INTO naive_bayes_prediction VALUES (null,$values)";
        if (!mysqli_query($con, $query)) {
            die("Error inserting data: " . mysqli_error($con));
        }
    }

    // Hitung akurasi dan confusion matrix
    $metrics = calculateMetrics($testData, $predictions);
    echo $metrics;
}

// Ambil data dari tabel naive_bayes_prediction
$predictionData = [];
$result = mysqli_query($con, "SELECT * FROM naive_bayes_prediction");
while ($row = mysqli_fetch_assoc($result)) {
    $predictionData[] = $row;
}

?>


<!-- HTML untuk antarmuka -->
<div class="app-content-header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <h3 class="mb-0">Data Prediction</h3>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Data Prediction</li>
                </ol>
            </div>
        </div>
        <form method="POST" action="" enctype="multipart/form-data">
            <div class="form-group">
                <label>Upload Excel File</label>
                <input type="file" name="file" class="form-control">
            </div>
            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-success">Upload</button>
            </div>
        </form>
    </div>
</div>

<div class="app-content">
    <div class="container-fluid">
        <div class="row">
            <div class="card">
                <div class="card-header">
                    <h1>Hasil Prediksi</h1>
                </div>
                <div class="container-fluid">
                    <table id="example2" class="table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Jenis Kelamin</th>
                                <th>Variasi Produk</th>
                                <th>Harga Produk</th>
                                <th>Interaksi Penjual</th>
                                <th>Pelayanan Pelanggan</th>
                                <th>Kualitas Produk</th>
                                <th>Proses Pembelian</th>
                                <th>Kecepatan Respon</th>
                                <th>Penanganan Keluhan</th>
                                <th>Kelas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; ?>
                            <?php foreach ($predictionData as $data) : ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= htmlspecialchars($data['jenis_kelamin'] ?? ''); ?></td>
                                    <td><?= htmlspecialchars($data['variasi_produk'] ?? ''); ?></td>
                                    <td><?= htmlspecialchars($data['harga_produk'] ?? ''); ?></td>
                                    <td><?= htmlspecialchars($data['interaksi_penjual'] ?? ''); ?></td>
                                    <td><?= htmlspecialchars($data['pelayanan_pelanggan'] ?? ''); ?></td>
                                    <td><?= htmlspecialchars($data['kualitas_produk'] ?? ''); ?></td>
                                    <td><?= htmlspecialchars($data['proses_pembelian'] ?? ''); ?></td>
                                    <td><?= htmlspecialchars($data['kecepatan_respon'] ?? ''); ?></td>
                                    <td><?= htmlspecialchars($data['penanganan_keluhan'] ?? ''); ?></td>
                                    <td><?= htmlspecialchars($data['kelas'] ?? ''); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php
// Koneksi ke database


// Ambil data dari tabel naive_bayes_prediction
$query = "SELECT kelas, predicted_class FROM naive_bayes_prediction";
$result = $con->query($query);

// Periksa apakah data ada
if ($result->num_rows === 0) {
    die("Tidak ada data dalam tabel naive_bayes_prediction.");
}

// Array untuk menyimpan label aktual dan prediksi
$actualLabels = [];
$predictedLabels = [];

// Ambil data untuk confusion matrix
while ($row = $result->fetch_assoc()) {
    $actualLabels[] = $row['kelas'];
    $predictedLabels[] = $row['predicted_class'];
}

// Fungsi untuk menghitung confusion matrix
function calculateConfusionMatrix($actualLabels, $predictedLabels)
{
    $classes = array_unique(array_merge($actualLabels, $predictedLabels));
    $confusionMatrix = [];

    // Inisialisasi matriks dengan nilai nol
    foreach ($classes as $actualClass) {
        foreach ($classes as $predictedClass) {
            $confusionMatrix[$actualClass][$predictedClass] = 0;
        }
    }

    // Hitung nilai untuk matriks
    foreach ($actualLabels as $index => $actualClass) {
        $predictedClass = $predictedLabels[$index];
        $confusionMatrix[$actualClass][$predictedClass]++;
    }

    return $confusionMatrix;
}

// Fungsi untuk menghitung presisi
function calculatePrecision($confusionMatrix)
{
    $precision = [];
    foreach ($confusionMatrix as $class => $row) {
        $truePositive = $confusionMatrix[$class][$class] ?? 0;
        $predictedPositive = array_sum(array_column($confusionMatrix, $class));
        $precision[$class] = ($predictedPositive > 0) ? $truePositive / $predictedPositive : 0;
    }
    return $precision;
}

// Hitung confusion matrix
$confusionMatrix = calculateConfusionMatrix($actualLabels, $predictedLabels);

// Hitung presisi untuk setiap kelas
$precision = calculatePrecision($confusionMatrix);

// Hitung akurasi
function calculateAccuracy($actualLabels, $predictedLabels)
{
    $correctPredictions = 0;
    $total = count($actualLabels);

    foreach ($actualLabels as $index => $actualClass) {
        if ($actualClass === $predictedLabels[$index]) {
            $correctPredictions++;
        }
    }

    return $correctPredictions / $total;
}

// Hitung akurasi
$accuracy = calculateAccuracy($actualLabels, $predictedLabels);

// Tampilkan confusion matrix di HTML
echo "<h3>Confusion Matrix</h3>";
echo '<table class="table table-bordered table-striped table-hover">';
echo "<tr><th>Actual \ Predicted</th>";

// Tampilkan header kolom (kelas prediksi)
$classes = array_keys($confusionMatrix);
foreach ($classes as $class) {
    echo "<th>$class</th>";
}
echo "</tr>";

// Tampilkan isi confusion matrix
foreach ($confusionMatrix as $actualClass => $row) {
    echo "<tr>";
    echo "<th>$actualClass</th>"; // Kelas aktual
    foreach ($classes as $predictedClass) {
        echo "<td>{$row[$predictedClass]}</td>";
    }
    echo "</tr>";
}
echo "</table>";

// Tampilkan presisi
echo "<h3>Precision for Each Class</h3>";
echo '<table class="table table-bordered table-striped table-hover">';
echo "<tr><th>Class</th><th>Precision</th></tr>";

foreach ($precision as $class => $value) {
    echo "<tr><td>$class</td><td>" . $value . "</td></tr>";
}
echo "</table>";

// Tampilkan akurasi
echo "<h3>Accuracy: " . round($accuracy * 100, 2) . "%</h3>";

// Tutup koneksi
$con->close();
?>
                </div>
            </div>
        </div>
    </div>
</div>
