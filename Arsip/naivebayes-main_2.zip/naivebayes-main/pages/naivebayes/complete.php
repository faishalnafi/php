<?php
use Phpml\Classification\NaiveBayes;
use Phpml\Metric\ConfusionMatrix;
use Phpml\Metric\Accuracy;

// Koneksi ke database
$pdo = new PDO('mysql:host=localhost;dbname=naive_bayes_db', 'root', '');

// Ambil data dari database
$data = mysqli_query($con,'SELECT * FROM naive_bayes');
$samples = [];
$labels = [];

while ($row = mysqli_fetch_assoc($data)) {
    $samples[] = [$row['feature1'], $row['feature2'], $row['feature3']];
    $labels[] = $row['label'];
}

// Pisahkan data menjadi training dan testing
$trainSize = (int)(count($samples) * 0.8); // 80% training, 20% testing
$trainSamples = array_slice($samples, 0, $trainSize);
$trainLabels = array_slice($labels, 0, $trainSize);

$testSamples = array_slice($samples, $trainSize);
$testLabels = array_slice($labels, $trainSize);

// Buat dan latih classifier Naive Bayes
$classifier = new NaiveBayes();
$classifier->train($trainSamples, $trainLabels);

// Lakukan prediksi pada data testing
$predictedLabels = [];
foreach ($testSamples as $sample) {
    $predictedLabels[] = $classifier->predict($sample);
}

// Buat Confusion Matrix
$confusionMatrix = ConfusionMatrix::compute($testLabels, $predictedLabels);

// Hitung akurasi
$accuracy = Accuracy::score($testLabels, $predictedLabels);

// Tampilkan hasil
echo "Confusion Matrix:\n";
print_r($confusionMatrix);

echo "\nAkurasi: " . ($accuracy * 100) . "%\n";
