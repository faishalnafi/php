<?php
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use Phpml\Classification\NaiveBayes;

// Koneksi ke database
if (!$con) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

if (isset($_POST['submit']) && isset($_FILES['file'])) {
    $file = $_FILES['file']['tmp_name'];

    if (empty($file)) {
        die('File tidak diunggah.');
    }
    if(is_uploaded_file($_FILES['file']['tmp_name'])){
        // Membaca file Excel
        $reader = new Xlsx();
        $reader->setLoadSheetsOnly('NAIVE BAYES');
        $spreadsheet = $reader->load($_FILES['file']['tmp_name']);
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray();
        unset($rows[0]);
        mysqli_query($con, "TRUNCATE TABLE naive_bayes_test"); 
        foreach ($rows as $Row)
        {
        
        $jk = isset($Row[0]) ? $Row[0] : '';
        $variasiproduk = isset($Row[1]) ? $Row[1] : '';
        $hargaproduk = isset($Row[2]) ? $Row[2] : '';
        $interaksipenjual = isset($Row[3]) ? $Row[3] : '';
        $pelayananpelanggan = isset($Row[4]) ? $Row[4] : '';
        $kualitasproduk = isset($Row[5]) ? $Row[5] : '';
        $prosespembelian = isset($Row[6]) ? $Row[6] : '';
        $kecepatanrespon = isset($Row[7]) ? $Row[7] : '';
        $penanganankeluhan = isset($Row[8]) ? $Row[8] : '';
        $kelas = isset($Row[9]) ? $Row[9] : '';
        
        //$query = "insert into naive_bayes_train values('".$jk."','".$variasiproduk."','".$hargaproduk."','".$interaksipenjual."','".$pelayananpelanggan."','".$kualitasproduk."','".$prosespembelian."','".$kecepatanrespon."','".$penanganankeluhan."','".$kelas."')";
        mysqli_query($con,"INSERT INTO naive_bayes_test VALUES(null,'$jk','$variasiproduk','$hargaproduk','$interaksipenjual','$pelayananpelanggan','$kualitasproduk','$prosespembelian','$kecepatanrespon','$penanganankeluhan','$kelas')");
        }
    }

    // Mengambil data dari tabel naive_bayes_train
    $trainingData = [];
    $labels = [];
    $result = mysqli_query($con, "SELECT * FROM naive_bayes_train");
    while ($row = mysqli_fetch_assoc($result)) {
        $trainingData[] = [
            $row['jenis_kelamin'], $row['variasi_produk'], $row['harga_produk'], $row['interaksi_penjual'],
            $row['pelayanan_pelanggan'], $row['kualitas_produk'], $row['proses_pembelian'], $row['kecepatan_respon'], $row['penanganan_keluhan']
        ];
        $labels[] = $row['kelas'];
    }

    // Pisahkan data pengujian dari file Excel
    $testingData = [];
    $testingLabels = [];
    foreach ($rows as $row) {
        $testingData[] = [
            $row[0], $row[1], $row[2], $row[3], $row[4],
            $row[5], $row[6], $row[7], $row[8]
        ];
        $testingLabels[] = $row[9]; // Kolom 'kelas'
    }

    // Kombinasikan data training dan testing untuk meningkatkan akurasi
    $combinedData = array_merge($trainingData, $testingData);
    $combinedLabels = array_merge($labels, $testingLabels);

    // Latih model Naive Bayes
    $classifier = new NaiveBayes();
    $classifier->train($combinedData, $combinedLabels);

    // Prediksi data pengujian
    $predictions = [];
    mysqli_query($con, "TRUNCATE TABLE naive_bayes_prediction"); // Bersihkan tabel prediksi

    foreach ($testingData as $index => $data) {
        $predictedClass = $classifier->predict($data);
        $dataWithClass = array_merge($data, [$testingLabels[$index]]);

        // Simpan hasil prediksi ke tabel `naive_bayes_prediction`
        $query = "INSERT INTO naive_bayes_prediction (jenis_kelamin, variasi_produk, harga_produk, interaksi_penjual, pelayanan_pelanggan, kualitas_produk, proses_pembelian, kecepatan_respon, penanganan_keluhan, kelas, predicted_class) 
                  VALUES ('" . implode("','", array_map(function ($value) use ($con) {
            return mysqli_real_escape_string($con, $value);
        }, $dataWithClass)) . "', '$predictedClass')";
        mysqli_query($con, $query);

        $predictions[] = $predictedClass;
    }
}
?>

<?php
//$confusionMatrix, true
$data = mysqli_query($con,"SELECT * FROM naive_bayes_test");
$numdata = mysqli_num_rows($data);
$dataArray = [];
$datatrain = floor($numdata * 0.075);
while($row = mysqli_fetch_assoc($data)){
    $dataArray[] = $row;
}
$no = 1;
?>
<div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0">Data Test</h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    Data Test
                                </li>
                            </ol>
                        </div>
                    </div>
                    <form method="POST" action="" enctype="multipart/form-data">
                            <div class="form-group">
                                    <label>Upload Excel File</label>
                                    <input type="file" name="file" class="form-control">
                            </div>
                            <div class="form-group">
                                    <button type="submit" name="submit" class="btn btn-success">Upload</button>
                            </div>
                    </form>
                    <!--end::Row-->
                </div>
                <!--end::Container-->
            </div>
<div class="app-content">
        <div class="container-fluid">
                <div class="row">
                        <div class="card">
                                <div class="card-header">
                                        <h1>Data Testing</h1>
                                </div>
                                <div class="card-body">
                                        <h2>Testing Table</h2>
                                        <table id="example2" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                        <tr>
                                                                <th>No</th>
                                                                <th>Jenis Kelamin</th>
                                                                <th>Variasi Produk</th>
                                                                <th>Harga Produk</th>
                                                                <th>Interaksi Penjual</th>
                                                                <th>Pelayanan Pelanggan</th>
                                                                <th>Kualitas Produk</th>
                                                                <th>Proses Pembelian</th>
                                                                <th>Kecepatan Respon</th>
                                                                <th>Penanganan Keluhan</th>
                                                                <th>Kelas</th>
                                                        </tr>
                                                </thead>
                                                <tbody>
                                                        <?php for ($i=0; $i < $datatrain; $i++) { ?>
                                        
                                                        <tr>
                                                        <td><?php echo $no++?></td>
                        <td><?php echo $dataArray[$i]['jenis_kelamin'] ?? '';?></td>
                        <td><?php echo $dataArray[$i]['variasi_produk'] ?? '';?></td>
                        <td><?php echo $dataArray[$i]['harga_produk'] ?? '';?></td>
                        <td><?php echo $dataArray[$i]['interaksi_penjual'] ?? '';?></td>
                        <td><?php echo $dataArray[$i]['pelayanan_pelanggan'] ?? '';?></td>
                        <td><?php echo $dataArray[$i]['kualitas_produk'] ?? '';?></td>
                        <td><?php echo $dataArray[$i]['proses_pembelian'] ?? '';?></td>
                        <td><?php echo $dataArray[$i]['kecepatan_respon'] ?? '';?></td>
                        <td><?php echo $dataArray[$i]['penanganan_keluhan'] ?? '';?></td>
                        <td><?php echo $dataArray[$i]['kelas'] ?? '';?></td>
                                                        </tr>
                                                        <?php } ?>
                                                </tbody>
                                        </table>
                                </div>
                        </div>
                </div>
                
        </div>
</div>