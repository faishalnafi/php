<?php
$id = $_GET['id'];
if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    mysqli_query($con,"UPDATE users SET name='$name', email='$email', password='$password', no_telp='$phone' WHERE id='$id'");
    echo "<script>window.location.href='index.php?p=user'</script>";
    $_SESSION['status'] = 'edit';
}

$data = mysqli_query($con,"SELECT * FROM users WHERE id='$id'");
$user = mysqli_fetch_assoc($data);
?>

<div class="app-content-header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <h3 class="mb-0">User</h3>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                    <li class="breadcumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                        User
                    </li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="app-content">
    <div class="container-fluid">
        <div class="row">
            <div class="card">
                <div class="card-header">
                    <h1>Edit User</h1>
                </div>
                <div class="card-body">
                    <form action="" method="post">
                        <label for="" class="form-label">Name</label>
                        <input type="text" name="name" id="" class="form-control" value="<?= $user['name'] ?>">
                        <label for="" class="form-label">Email</label>
                        <input type="email" name="email" id="" class="form-control" value="<?= $user['email'] ?>">
                        <label for="" class="form-label">Password</label>
                        <input type="password" name="password" id="" class="form-control" value="<?= $user['password'] ?>">
                        <label for="" class="form-label">Nomor Telepon</label>
                        <input type="text" name="phone" id="" class="form-control" value="<?= $user['no_telp'] ?>">
                        <br>
                        <a href="index.php?p=user" class="btn btn-primary">Kembali</a>
                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>