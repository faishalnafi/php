<?php
if(isset($_GET['delete'])){
    $id=$_GET['id'];
    mysqli_query($con,"DELETE FROM users WHERE id='$id'");
    $_SESSION['status'] = 'delete';
    echo "<script>window.location.href='index.php?p=user'</script>";
}
?>

<style>
     .expandable-btn {
      display: inline-flex; /* Flex untuk rata tengah konten */
      align-items: center; /* Pastikan ikon dan teks sejajar vertikal */
      overflow: hidden; /* Cegah teks keluar batas */
      transition: width 0.3s ease; /* Animasi pelebaran */
      width: 40px; /* Lebar awal tombol */
      height: 40px; /* Tinggi tombol tetap */
      padding: 0 12.5px; /* Padding horizontal untuk jarak ikon */
      border-radius: 5px; /* Membuat tombol sedikit melengkung */
      white-space: nowrap; /* Mencegah teks membungkus */
    }

    .expandable-btn:hover {
      width: 135px; /* Lebar tombol saat hover */
    }

    .expandable-btn i {
      margin-right: 10px; /* Jarak antara ikon dan teks */
    }

    .expandable-btn span {
      opacity: 0; /* Sembunyikan teks secara default */
      transition: opacity 0.3s ease; /* Animasi teks muncul */
    }

    .expandable-btn:hover span {
      opacity: 1; /* Tampilkan teks saat hover */
    }
</style>
<div class="app-content-header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <h3 class="mb-0">User</h3>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                        User
                    </li>
                </ol>
            </div>
        </div>
    </div>
</div>
<?php
$data = mysqli_query($con,"SELECT * FROM users");
$no = 1;

?>
<div class="app-content">
    
    <div class="container-fluid">
        <div class="d-flex justify-content-end">
        <a href="index.php?p=user&act=create" class="btn btn-primary expandable-btn">
            <i class="fa-solid fa-plus"></i>
            <span>Create User</span>
        </a>

        </div>
        <?php
        if(isset($_SESSION['status'])){
            if($_SESSION['status'] == 'success'){ ?>
            <div class="alert alert-success" role="alert">
                <p>Create user successful!</p>
            </div>
        <?php   }else if($_SESSION['status'] == 'delete'){ ?>
            <div class="alert alert-success" role="alert">
            <p>Delete user successful!</p>
            </div>
        <?php }else if($_SESSION['status'] == 'edit'){ ?>
            <div class="alert alert-success" role="alert">
            <p>Update user successful!</p>
            </div>
        <?php }
             unset($_SESSION['status']); 
        }
        ?>
        <table id="example2" class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($data as $user){ ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $user['name'] ?></td>
                        <td><?= $user['email'] ?></td>
                        <td>
                            <a href="index.php?p=user&act=edit&id=<?= $user['id']?>" class="btn btn-primary expandable-btn" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit User">
                                <i class="fa-solid fa-pen-to-square"></i>
                                <span>Edit User</span>
                            </a>
                            <a href="?p=user&delete&id=<?= $user['id']?>" class="btn btn-danger expandable-btn" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete User">
                                <i class="fa-regular fa-trash-can"></i>
                                <span>Delete User</span>
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>