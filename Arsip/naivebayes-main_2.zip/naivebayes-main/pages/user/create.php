<?php

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    mysqli_query($con,"INSERT INTO users VALUES (null,'$name','$email','$password','$phone')");
    echo "<script>window.location.href='index.php?p=user'</script>";
    $_SESSION['status'] = 'success';
}
?>

<div class="app-content-header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <h3 class="mb-0">User</h3>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                    <li class="breadcumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                        User
                    </li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="app-content">
    <div class="container-fluid">
        <div class="row">
            <div class="card">
                <div class="card-header">
                    <h1>Create User</h1>
                </div>
                <div class="card-body">
                    <form action="" method="post">
                        <label for="" class="form-label">Name</label>
                        <input type="text" name="name" id="" class="form-control">
                        <label for="" class="form-label">Email</label>
                        <input type="email" name="email" id="" class="form-control">
                        <label for="" class="form-label">Password</label>
                        <input type="password" name="password" id="" class="form-control">
                        <label for="" class="form-label">Nomor Telepon</label>
                        <input type="text" name="phone" id="" class="form-control">
                        <br>
                        <a href="index.php?p=user" class="btn btn-primary">Kembali</a>
                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>