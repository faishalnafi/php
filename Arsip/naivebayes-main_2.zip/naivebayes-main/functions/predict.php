<?php
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Fungsi untuk menghitung probabilitas Naive Bayes
function naiveBayesPredict($data, $trainingData) {
    $classProbabilities = [];
    $featureProbabilities = [];

    foreach ($trainingData as $row) {
        $class = $row['kelas'];
        $classProbabilities[$class] = ($classProbabilities[$class] ?? 0) + 1;

        foreach ($data as $feature => $value) {
            if (!isset($featureProbabilities[$class][$feature])) {
                $featureProbabilities[$class][$feature] = [];
            }
            $featureProbabilities[$class][$feature][$value] = ($featureProbabilities[$class][$feature][$value] ?? 0) + 1;
        }
    }

    $totalTrainingData = count($trainingData);
    foreach ($classProbabilities as $class => $count) {
        $classProbabilities[$class] = $count / $totalTrainingData;
    }

    foreach ($featureProbabilities as $class => $features) {
        foreach ($features as $feature => $values) {
            $totalFeatureCount = array_sum($values);
            foreach ($values as $value => $count) {
                $featureProbabilities[$class][$feature][$value] = $count / $totalFeatureCount;
            }
        }
    }

    $predictions = [];
    foreach ($classProbabilities as $class => $classProbability) {
        $probability = $classProbability;
        foreach ($data as $feature => $value) {
            $probability *= $featureProbabilities[$class][$feature][$value] ?? 1e-6;
        }
        $predictions[$class] = $probability;
    }

    arsort($predictions);
    return key($predictions);
}

// Fungsi untuk menghitung akurasi dan confusion matrix
function calculateMetrics($testData, $predictions) {
    $confusionMatrix = [];
    $correctPredictions = 0;
    $totalData = count($testData);

    foreach ($testData as $index => $row) {
        $actualClass = $row['kelas'];
        $predictedClass = $predictions[$index]['predicted_class'] ?? null;

        if (!isset($confusionMatrix[$actualClass])) {
            $confusionMatrix[$actualClass] = [];
        }

        if (!isset($confusionMatrix[$actualClass][$predictedClass])) {
            $confusionMatrix[$actualClass][$predictedClass] = 0;
        }

        $confusionMatrix[$actualClass][$predictedClass]++;

        if ($actualClass === $predictedClass) {
            $correctPredictions++;
        }
    }

    $accuracy = $correctPredictions / $totalData;

    return [
        'accuracy' => $accuracy,
        'confusionMatrix' => $confusionMatrix,
    ];
}


if (isset($submit) && isset($files)) {
    $file = $files['tmp_name'];

    if (empty($file)) {
        die('No file uploaded.');
    }

    $reader = new Xlsx();
    $reader->setLoadSheetsOnly('NAIVE BAYES');
    $spreadsheet = $reader->load($file);
    $sheet = $spreadsheet->getActiveSheet();
    $rows = $sheet->toArray();

    foreach ($rows as $Row)
        {
        
        $jk = isset($Row[0]) ? $Row[0] : '';
        $variasiproduk = isset($Row[1]) ? $Row[1] : '';
        $hargaproduk = isset($Row[2]) ? $Row[2] : '';
        $interaksipenjual = isset($Row[3]) ? $Row[3] : '';
        $pelayananpelanggan = isset($Row[4]) ? $Row[4] : '';
        $kualitasproduk = isset($Row[5]) ? $Row[5] : '';
        $prosespembelian = isset($Row[6]) ? $Row[6] : '';
        $kecepatanrespon = isset($Row[7]) ? $Row[7] : '';
        $penanganankeluhan = isset($Row[8]) ? $Row[8] : '';
        $kelas = isset($Row[9]) ? $Row[9] : '';
        
        $query = "insert into naive_bayes_test values('".$jk."','".$variasiproduk."','".$hargaproduk."','".$interaksipenjual."','".$pelayananpelanggan."','".$kualitasproduk."','".$prosespembelian."','".$kecepatanrespon."','".$penanganankeluhan."','".$kelas."')";
        mysqli_query($con,"INSERT INTO naive_bayes_test VALUES(null,'$jk','$variasiproduk','$hargaproduk','$interaksipenjual','$pelayananpelanggan','$kualitasproduk','$prosespembelian','$kecepatanrespon','$penanganankeluhan','$kelas')");
        }
    $header = array_shift($rows); // Ambil header
    $predictions = [];

    // Ambil data training dari database
    $trainingData = [];
    $result = mysqli_query($con, "SELECT * FROM naive_bayes_train");
    while ($row = mysqli_fetch_assoc($result)) {
        $trainingData[] = $row;
    }

    // Ambil data testing dari database
    $testData = [];
    $result = mysqli_query($con, "SELECT * FROM naive_bayes_test");
    while ($row = mysqli_fetch_assoc($result)) {
        $testData[] = $row;
    }

    foreach ($rows as $row) {
        $data = array_combine($header, $row);
        $predictedClass = naiveBayesPredict($data, $trainingData);
        $predictions[] = array_merge($data, ['predicted_class' => $predictedClass]);
    }
    
    // Simpan hasil prediksi ke tabel testing
    foreach ($predictions as $prediction) {
        $filteredPrediction = array_filter($prediction, function ($value) {
            return $value !== null; // Hanya ambil nilai yang tidak null
        });
        $columns = implode(',', array_keys($filteredPrediction));
        $values = implode(',', array_map(function ($value) use ($con) {
            return "'" . mysqli_real_escape_string($con, (string) $value) . "'";
        }, array_values($filteredPrediction)));

        $columns = strtolower(str_replace(' ', '_', $columns));
        $query = "INSERT INTO naive_bayes_prediction VALUES (null,$values)";
        if (!mysqli_query($con, $query)) {
            die("Error inserting data: " . mysqli_error($con));
        }
    }

    // Hitung akurasi dan confusion matrix
    // $metrics = calculateMetrics($testData, $predictions);
    // echo $metrics;
}


// Upload file Excel
